package databasetesting;

import java.sql.SQLException;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class db_testing extends db_connect {
    String errorMessage = "default message";

    @BeforeClass
    public void setup() throws ClassNotFoundException, SQLException {
        establish_connection();
    }

    @Test
    public void verifyPrimaryKeyConstraint() throws SQLException {
        try {
            int pkKey = 1101; // Duplicate key for testing
            int n = exe_insert(pkKey);
            System.out.println("Number of rows inserted: " + n);
            Assert.assertTrue(n > 0, "Insert should succeed");
        } catch (Exception e) {
            errorMessage = e.getMessage();
            System.out.println("Exception caught: " + errorMessage);
            Assert.assertTrue(errorMessage.toLowerCase().contains("duplicate key"),
                    "Exception duplicate key not thrown");
        }
    }
}