package databasetesting;

import java.sql.*;

public class db_connect {
    static String url = "jdbc:postgresql://localhost:5432/db4"; // DB URL
    static String user = "postgres"; // DB username
    static String password = "jmqateam@2025"; // DB password

    static Connection con = null;
    static Statement stmt = null;
    static ResultSet rs = null;
    static PreparedStatement pStmt = null;

    // Establish connection
    public static void establish_connection() throws ClassNotFoundException, SQLException {
        Class.forName("org.postgresql.Driver");
        con = DriverManager.getConnection(url, user, password);
        System.out.println("Connection successful!");
    }

    // Insert method
    public int exe_insert(int pkKey) throws SQLException {
        String sql = "INSERT INTO emp (emp_id, emp_name, dept_id) VALUES (?, ?, ?)";
        pStmt = con.prepareStatement(sql);
        pStmt.setInt(1, pkKey);
        pStmt.setString(2, "Dhoni");
        pStmt.setInt(3, 101);
        int rowsInserted = pStmt.executeUpdate();
        return rowsInserted;
    }
}
