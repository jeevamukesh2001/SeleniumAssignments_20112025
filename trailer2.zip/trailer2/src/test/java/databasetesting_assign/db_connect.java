package databasetesting_assign;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class db_connect {
    static String url = "jdbc:postgresql://localhost:5432/db4"; // DB URL
    static String user = "postgres"; // DB username
    static String password = "jmqateam@2025"; // DB password

    static Connection con = null;
    static Statement stmt = null;
    static ResultSet rs = null;
    static PreparedStatement pStmt = null;

    // Establish connection
    public static void establish_connection() throws ClassNotFoundException, SQLException {
        Class.forName("org.postgresql.Driver");
        con = DriverManager.getConnection(url, user, password);
        System.out.println("Connection successful!");
    }

    // Insert method
    public int insertdata(String name) throws SQLException {
        String sql = "INSERT INTO students VALUES (?, ?, ?, ?)";
        pStmt = con.prepareStatement(sql);
        pStmt.setString(1, name);
        pStmt.setInt(2, 45);
        pStmt.setString(3, "Chennai");
        pStmt.setInt(4, 80000000);
        int rowsInserted = pStmt.executeUpdate();
        return rowsInserted;
    }

    // Fetch data and return list of Student objects
    public List<Student> getstudent() throws SQLException {
        List<Student> students = new ArrayList<>();
        String sql = "SELECT sname, sage, slocation, ssalary FROM students";
        pStmt = con.prepareStatement(sql);
        rs = pStmt.executeQuery();
        while (rs.next()) {
            String name = rs.getString("sname");
            int age = rs.getInt("sage");
            String location = rs.getString("slocation");
            int salary = rs.getInt("ssalary");
            Student student = new Student(name, age, location, salary);
            students.add(student);
        }
        return students;
    }
    
    // Delete all records
    public void deletedata() throws SQLException {
        String sql = "DELETE FROM students";
        stmt=con.createStatement();
        stmt.executeUpdate(sql);
        System.out.println("Records deleted successfully");
    }
}