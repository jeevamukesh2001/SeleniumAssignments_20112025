package databasetesting_assign;

class Student {
    String name;
    int age;
    String location;
    int salary;

    public Student(String name, int age, String location, int salary) {
        this.name = name;
        this.age = age;
        this.location = location;
        this.salary = salary;
    }

	public void display() {
		System.out.println(name+" "+age+" "+location+" "+salary);
	}
}