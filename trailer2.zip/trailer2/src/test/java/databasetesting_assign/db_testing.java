package databasetesting_assign;

import java.sql.SQLException;
import java.util.List;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class db_testing extends db_connect {
    String errorMessage = "default message";

    @BeforeClass
    public void setup() throws ClassNotFoundException, SQLException {
        establish_connection();
    }

    @Test
    public void insert() throws SQLException {
    	String name = "Rana";
    	int n = insertdata(name);
        System.out.println("Number of rows inserted: " + n);
    }
    
    @Test
    public void Display() throws SQLException {
    	List<Student>s=getstudent();
    	s.get(0);
    	for(Student s5:s) {
			s5.display();
		}
    	System.out.println(s.size());
    }
    
    @Test
    public void Delete() throws SQLException {
    	deletedata();
    }
}