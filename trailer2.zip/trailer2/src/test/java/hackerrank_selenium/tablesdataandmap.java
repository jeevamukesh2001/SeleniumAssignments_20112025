package hackerrank_selenium;

import java.util.HashMap;
import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class tablesdataandmap {
	public static void extract(WebDriver dr, Map<String, Integer> map) {
    	for (int r = 1; r <= 5; r++) {
            String salary = "//table[@class='table table-striped mt-3']/tbody/tr[" + r + "]/td[5]";
            String salaryText = dr.findElement(By.xpath(salary)).getText();
            int sal = Integer.parseInt(salaryText);
            String dept = "//table[@class='table table-striped mt-3']/tbody/tr[" + r + "]/td[6]";
            String deptName = dr.findElement(By.xpath(dept)).getText();
            System.out.print(deptName+" "+sal+" ");
            if(map.containsKey(deptName)) {
            	map.put(deptName, map.get(deptName) + sal);
            } else {
            	map.put(deptName, sal);
            }
        }
    	System.out.println();
    	for (String res : map.keySet()) {
            System.out.println(res + " : " + map.get(res));
        }
    }
	
    public static void main(String[] args) {
        String url = "https://www.tutorialspoint.com/selenium/practice/webtables.php";
        System.setProperty("webdriver.chrome.driver", "chromedriver_v141.exe");
        WebDriver dr = new ChromeDriver();
        dr.get(url);
        dr.manage().window().maximize();
        Map<String, Integer> data = new HashMap<>();
        extract(dr,data);
        dr.quit();
    }
}
