package hackerrank_selenium;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class webelementcount {
	public static void linkcount(WebDriver dr) {
		List<WebElement> link=dr.findElements(By.tagName("a"));
		System.out.println("No. of links : "+link.size());
	}
	
	public static void textboxcount(WebDriver dr) {
		List<WebElement> text=dr.findElements(By.xpath("//input[@type='text']"));
		System.out.println("No. of textboxes : "+text.size());
	}
	
	public static void radiobuttoncount(WebDriver dr) {
		List<WebElement> radio=dr.findElements(By.xpath("//input[@type='radio']"));
		System.out.println("No. of radiobuttons : "+radio.size());
	}
	
	public static void checkboxcount(WebDriver dr) {
		List<WebElement> box=dr.findElements(By.xpath("//input[@type='checkbox']"));
		System.out.println("No. of checkboxes : "+box.size());
	}
	
	public static void inputbuttoncount(WebDriver dr) {
		List<WebElement> button1=dr.findElements(By.xpath("//input[@type='button']"));
		List<WebElement> button2=dr.findElements(By.xpath("//input[@type='submit']"));
		System.out.println("No. of buttons : "+(button1.size()+button2.size()));
	}
	
	public static void textcount(WebDriver dr) {
		List<WebElement> text1=dr.findElements(By.tagName("span"));
		List<WebElement> text2=dr.findElements(By.xpath("//div[@class='text']"));
		System.out.println("No. of texts : "+(text1.size()+text2.size()));
	}
	
	public static void headercount(WebDriver dr) {
		List<WebElement> header1=dr.findElements(By.tagName("h1"));
		List<WebElement> header2=dr.findElements(By.tagName("h2"));
		List<WebElement> header3=dr.findElements(By.tagName("h3"));
		System.out.println("No. of headers : "+(header1.size()+header2.size()+header3.size()));
	}
	
	public static void labelcount(WebDriver dr) {
		List<WebElement> label=dr.findElements(By.tagName("label"));
		System.out.println("No. of labels : "+label.size());
	}
	
	public static void strongtextcount(WebDriver dr) {
		List<WebElement> strong=dr.findElements(By.tagName("strong"));
		System.out.println("No. of Bold texts : "+strong.size());
	}
	
	public static void typeofinput(WebDriver dr) {
		List<WebElement> types=dr.findElements(By.tagName("input"));
		for (WebElement input : types) {
			String type = input.getDomAttribute("type");
			String name = input.getDomAttribute("name");
			System.out.println("Input Name: " + name + " | Type: " + type);
		}
	}
	
    public static void main(String[] args) {
        String url1 = "https://demowebshop.tricentis.com/Register";
        System.setProperty("webdriver.chrome.driver", "chromedriver_v141.exe");
        WebDriver dr = new ChromeDriver();
        dr.get(url1);
        dr.manage().window().maximize();
        linkcount(dr);
        textboxcount(dr);
        radiobuttoncount(dr);
        checkboxcount(dr);
        inputbuttoncount(dr);
        textcount(dr);
        headercount(dr);
        labelcount(dr);
        strongtextcount(dr);
        typeofinput(dr);
        System.out.println();
        String url2 = "https://demowebshop.tricentis.com/Login";
        dr.get(url2);
        linkcount(dr);
        textboxcount(dr);
        radiobuttoncount(dr);
        checkboxcount(dr);
        inputbuttoncount(dr);
        textcount(dr);
        headercount(dr);
        labelcount(dr);
        strongtextcount(dr);
        typeofinput(dr);
        dr.quit();
    }
}
