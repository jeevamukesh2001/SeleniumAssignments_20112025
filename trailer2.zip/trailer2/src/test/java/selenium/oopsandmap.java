package selenium;

import java.util.*;

public class oopsandmap {
    String country;
    int totalCases;
    int totalDeaths;
    int totalRecovered;
    String continent;

    public oopsandmap(String country, int totalCases, int totalDeaths, int totalRecovered, String continent) {
        this.country = country;
        this.totalCases = totalCases;
        this.totalDeaths = totalDeaths;
        this.totalRecovered = totalRecovered;
        this.continent = continent;
    }
    
    static Map<String, Integer> totalCasesPerContinent = new HashMap<>();
    static Map<String, Integer> countryCountPerContinent = new HashMap<>();
    
    public static void map(oopsandmap... Object) { // Object o1,Object o2,Object o3,Object o4,Object o5
    	for(oopsandmap data:Object) {    // Arrays.asList(o1,o2,o3,o4,o5)
            if (totalCasesPerContinent.containsKey(data.continent) && countryCountPerContinent.containsKey(data.continent)) {
            	totalCasesPerContinent.put(data.continent, totalCasesPerContinent.get(data.continent) + data.totalCases);
                countryCountPerContinent.put(data.continent, countryCountPerContinent.get(data.continent) + 1);
            } else {
            	totalCasesPerContinent.put(data.continent, data.totalCases);
                countryCountPerContinent.put(data.continent, 1);
            }
        }
    	
        System.out.println("Total Cases per Continent:");
        for (String continent : totalCasesPerContinent.keySet()) {
            System.out.println(continent + ": " + totalCasesPerContinent.get(continent));
        }

        System.out.println("\nCountry Count per Continent:");
        for (String continent : countryCountPerContinent.keySet()) {
            System.out.println(continent + ": " + countryCountPerContinent.get(continent));
        }
    }
    
//    public static void map(oopsandmap... Object) { // Object o1,Object o2,Object o3,Object o4,Object o5
//    	for(oopsandmap data:Object)) { // Arrays.asList(o1,o2,o3,o4,o5)
//    		totalCasesPerContinent.put(data.continent,totalCasesPerContinent.getOrDefault(data.continent,0)+data.totalCases);
//    		countryCountPerContinent.put(data.continent,countryCountPerContinent.getOrDefault(data.continent,0)+1);
//        }
//    }

    public static void main(String[] args) {
        oopsandmap europe1 = new oopsandmap("USA", 64700, 68, 64100, "Europe");
        oopsandmap asia1 = new oopsandmap("India", 64700, 68, 64100, "Asia");
        oopsandmap europe2 = new oopsandmap("Russia", 64700, 68, 64100, "Europe");
        oopsandmap europe3 = new oopsandmap("Brazil", 64700, 68, 64100, "Europe");
        oopsandmap asia2 = new oopsandmap("China", 64700, 68, 64100, "Asia");
        oopsandmap.map(europe1, asia1, europe2, europe3, asia2);
    }
}