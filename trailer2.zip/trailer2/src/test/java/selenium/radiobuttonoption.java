package selenium;

import java.time.Duration;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class radiobuttonoption {
    static Map<String, String> rbMap = new HashMap<>();
    public static void get_radio_buttons(WebDriver driver) {
        List<WebElement> options = driver.findElements(By.xpath("//ul[@class='poll-options']/li"));
        int index = 1;
        for (WebElement option : options) {
            String label = option.getText().trim();
            String xpathvalue = "//ul[@class='poll-options']/li[" + index + "]//input[@type='radio']";
            rbMap.put(label, xpathvalue);
            index++;
        }
    }

    public static void click_rb(WebDriver driver, String label) {
    	get_radio_buttons(driver);
        String xpath = rbMap.get(label);
        if (xpath != null) {
            WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
            wait.until(ExpectedConditions.elementToBeClickable(By.xpath(xpath))).click();
            System.out.println("Clicked radio button: " + label);
        } else {
            System.out.println("Label not found: " + label);
        }
    }

    public static void main(String[] args) {
        System.setProperty("webdriver.chrome.driver", "chromedriver_v141.exe");
        WebDriver driver = new ChromeDriver();
        driver.get("https://demowebshop.tricentis.com");
        driver.manage().window().maximize();
        click_rb(driver, "Excellent");
        click_rb(driver, "Good");
    }
}