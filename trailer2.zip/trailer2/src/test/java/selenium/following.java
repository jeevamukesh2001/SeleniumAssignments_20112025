package selenium;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class following {
    public static void main(String[] args) throws InterruptedException {
    	String url="https://demowebshop.tricentis.com";
		System.setProperty("webdriver.chrome.driver","chromedriver_v141.exe");
		WebDriver dr=new ChromeDriver();
		dr.get(url);
		dr.manage().window().maximize();
		WebElement fo1=dr.findElement(By.xpath("//div[@class='leftside-3']/following::input[3]"));
		System.out.println(fo1.getText());
		fo1.click();
		Thread.sleep(5000);
		dr.quit();
    }
}
