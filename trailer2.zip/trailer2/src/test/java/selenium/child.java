package selenium;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class child {
    public static void main(String[] args) {
    	String url="https://www.w3schools.com/html/html_lists.asp";
		System.setProperty("webdriver.chrome.driver","chromedriver_v141.exe");
		WebDriver dr=new ChromeDriver();
		dr.get(url);
		dr.manage().window().maximize();
		WebElement child1=dr.findElement(By.xpath("//div[@class='w3col w3-half'][2]/ol/child::li[1]"));
		System.out.println(child1.getText());
		WebElement child2=dr.findElement(By.xpath("//div[@class='w3col w3-half'][2]/ol/child::li[2]"));
		System.out.println(child2.getText());
		WebElement child3=dr.findElement(By.xpath("//div[@class='w3col w3-half'][2]/ol/child::li[3]"));
		System.out.println(child3.getText());
		WebElement child4=dr.findElement(By.xpath("//div[@class='w3col w3-half'][2]/ol/child::li[4]"));
		System.out.println(child4.getText());
		dr.quit();
    }
}
