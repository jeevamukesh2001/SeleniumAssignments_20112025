package selenium;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class descendent {
    public static void main(String[] args) {
    	String url="https://demowebshop.tricentis.com";
		System.setProperty("webdriver.chrome.driver","chromedriver_v141.exe");
		WebDriver dr;
		dr=new ChromeDriver();
		dr.get(url);
		dr.manage().window().maximize();
		WebElement des1=dr.findElement(By.xpath("//div[@class='leftside-3']/descendant::a[1]"));
		System.out.println(des1.getText());
		dr.quit();
    }
}
