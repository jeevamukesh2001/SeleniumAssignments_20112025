package selenium;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class tablesdata {
    public static void main(String[] args) throws InterruptedException {
    	String url="https://www.w3schools.com/html/html_tables.asp";
		System.setProperty("webdriver.chrome.driver","chromedriver_v141.exe");
		WebDriver dr=new ChromeDriver();
		dr.get(url);
		dr.manage().window().maximize();
		for(int r=2;r<=6;r++) {
			for(int c=1;c<=3;c++) {
				String xp1="//table[@id='customers']/tbody/tr["+r+"]/td["+c+"]";
				String s=dr.findElement(By.xpath(xp1)).getText();
				System.out.print(s+" ");
			}
			System.out.println();
		}
	}
}
