package selenium;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class ancestor {
    public static void main(String[] args) {
    	String url="https://www.w3schools.com/html/html_lists.asp";
		System.setProperty("webdriver.chrome.driver","chromedriver_v141.exe");
		WebDriver dr=new ChromeDriver();
		dr.get(url);
		dr.manage().window().maximize();
		WebElement ol=dr.findElement(By.xpath("//div[@class='w3col w3-half'][2]"));
		System.out.println(ol.getText());
		System.out.println("-----");
		WebElement anl1=dr.findElement(By.xpath("//div[@class='w3col w3-half'][1]/ancestor::div[1]"));
		System.out.println(anl1.getText());
		System.out.println("-----");
		WebElement anl2=dr.findElement(By.xpath("//div[@class='w3col w3-half'][1]/ancestor::div[2]"));
		System.out.println(anl2.getText());
		System.out.println("-----");
		dr.quit();
    }
}
