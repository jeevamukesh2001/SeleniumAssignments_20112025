package stepdef;

import java.util.HashMap;
import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.testng.Assert;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class login_steps {
	WebDriver dr;
	@Given("Login page is displayed")
	public void loginpage() {
		 System.setProperty("webdriver.chrome.driver", "chromedriver_v141.exe");
		 Map<String, Object> chromePrefs = new HashMap<>();
		 chromePrefs.put("credentials_enable_service", false);
		 chromePrefs.put("profile.password_manager_enabled", false);
		 chromePrefs.put("profile.password_manager_leak_detection", false);
		 ChromeOptions chromeOptions = new ChromeOptions();
		 chromeOptions.setExperimentalOption("prefs", chromePrefs);
		 dr = new ChromeDriver(chromeOptions);
		 dr.get("https://saucedemo.com");
		 dr.manage().window().maximize();
	}
	@When("user enters username and password")
	public void credentials() {
		WebElement user=dr.findElement(By.xpath("//input[@id='user-name']"));
		user.sendKeys("standard_user");
		WebElement pass=dr.findElement(By.xpath("//input[@id='password']"));
		pass.sendKeys("secret_sauce");
	}
	@When("user click login button")
	public void loginbutton() {
	    WebElement login=dr.findElement(By.xpath("//input[@id='login-button']"));
	    login.click();
	}
	@Then("the product page is displayed")
	public void next() throws InterruptedException {
		WebElement gettitle=dr.findElement(By.xpath("//span[@class='title']"));
		Assert.assertEquals("Products", gettitle.getText());
		Thread.sleep(2000);
		dr.quit();
	}
	@When("user enters invalid username and password")
	public void invalidcredentials() {
		WebElement user=dr.findElement(By.xpath("//input[@id='user-name']"));
		user.sendKeys("standard_sauce");
		WebElement pass=dr.findElement(By.xpath("//input[@id='password']"));
		pass.sendKeys("secret_sauce");
	}
	@Then("the error message is displayed")
	public void error() throws InterruptedException {
		WebElement geterror=dr.findElement(By.xpath("//h3[@data-test=\"error\"]"));
		Assert.assertEquals("Epic sadface: Username and password do not match any user in this service", geterror.getText());
		Thread.sleep(2000);
		dr.quit();
	}
}
