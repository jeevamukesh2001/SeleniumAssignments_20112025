package testng.automation;

import org.testng.annotations.Test;

public class exception {

	 @Test(expectedExceptions = ArrayIndexOutOfBoundsException.class)
	    public void testArrayOutOfBounds() {
	        int[] arr = {1, 2, 3};
	        System.out.println("Running testArrayOutOfBounds...");
	        int value = arr[5];
	        System.out.println("Value = " + value);
	    }
	}
