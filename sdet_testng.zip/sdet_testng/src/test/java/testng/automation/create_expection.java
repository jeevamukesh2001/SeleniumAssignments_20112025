package testng.automation;

import org.testng.annotations.Test;

public class create_expection {
	
	@Test(expectedExceptions = ArithmeticException.class)
	public void t1() {
		throw new ArithmeticException("AE occured");
	}
	
	@Test(expectedExceptions = ArrayIndexOutOfBoundsException.class)
    public void t2() {
        throw new ArrayIndexOutOfBoundsException("ArrayIndexOutOfBoundsException occurred");
    }

    @Test(expectedExceptions = NullPointerException.class)
    public void t3() {
        throw new NullPointerException("NullPointerException occurred");
    }

    @Test(expectedExceptions = NumberFormatException.class)
    public void t4() {
        throw new NumberFormatException("NumberFormatException occurred");
    }
}
