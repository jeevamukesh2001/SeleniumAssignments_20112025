package testng.automation;

import org.testng.annotations.Test;

public class testng_expection {
	@Test(expectedExceptions = ArithmeticException.class)
	public void testDivideByZero() {
		int a=10, b=0,c;
		System.out.println("Running test DivideByZero..");
		c=a/b;
		System.out.println("C = " + c);	
	}

}
