package testng.automation;

import org.testng.Assert;
import org.testng.annotations.Test;

public class ct {
	
	Calculate calc = new Calculate();
	
	@Test 
	public void test_divide() {
		int result = calc.divide(10, 2);
		Assert.assertEquals(result, 5);
	}
	
	@Test(expectedExceptions = ArithmeticException.class)
	public void  test_exception() {
		int result = calc.divide(10, 0);
	}

}
