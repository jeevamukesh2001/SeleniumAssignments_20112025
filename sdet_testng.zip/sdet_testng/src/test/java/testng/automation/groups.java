package testng.automation;

import org.testng.annotations.Test;

public class groups {
	
	@Test(groups = {"F1","F2"})
	public void test1() {
		System.out.println("Executing F1 & F2 testcases");
		
		
	}
	@Test(groups = {"F1"})
	public void test2() {
		System.out.println("Executing F1 testcases");
		
		
	}
	@Test(groups = {"F2"})
	public void test3() {
		System.out.println("Executing F2 testcases");
		
		
	}
	@Test(groups = {"F1"})
	public void test4() {
		System.out.println("Executing F1 testcases");
	}


}
