package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class login_page {
    WebDriver driver;
    
    @FindBy(xpath = "//a[@class='ico-login']")
    WebElement loginlink;

    @FindBy(xpath = "//input[@class='email']")
    WebElement email;

    @FindBy(xpath = "//input[@class='password']")
    WebElement pass;

    @FindBy(id = "RememberMe")
    WebElement rem;

    @FindBy(xpath = "//input[@class='button-1 login-button']")
    WebElement login;

    @FindBy(xpath = "//a[@class='account']")
    WebElement next;

    @FindBy(xpath = "//a[@class='ico-logout']")
    WebElement logout;
    
    @FindBy(xpath = "//div[@class=\"message-error\"]")
    WebElement error;

    public login_page(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }

    public void launch_chrome() {
        driver.get("https://demowebshop.tricentis.com/");
        driver.manage().window().maximize();
    }

    public void loginlinkclick() {
        loginlink.click();
    }

    public void loginuser(String user, String pwd) {
        loginlinkclick();
        email.sendKeys(user);
        pass.sendKeys(pwd);
    }

    public void remember() {
        rem.click();
    }

    public void loginbutton() {
        login.click();
    }
    
    public String actualEmail() {
    	return next.getText();
    }

    public void logout() {
        logout.click();
    }
    
    public String actualError() {
    	return error.getText().replaceAll("\\s+", " ").trim();
    }
}