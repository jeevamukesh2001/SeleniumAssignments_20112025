package stepdef;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;

import io.cucumber.java.en.*;
import pages.login_page;

public class login_steps {
    WebDriver dr;
    login_page lp;

    @Given("Login page is displayed")
    public void loginpage() {
        System.setProperty("webdriver.chrome.driver", "chromedriver_v141.exe");
        dr = new ChromeDriver();
        lp = new login_page(dr);
        lp.launch_chrome();
    }

    @When("user click login link")
    public void loginlink() {
        lp.loginlinkclick();
    }

    @When("user enters username and password")
    public void loginvaliduser() {
        lp.loginuser("jeevamukesh2@gmail.com", "jeeva@2001");
    }
    
    @When("user enters invalid username and password")
    public void logininvaliduser() {
        lp.loginuser("jeevamukesh0308@gmail.com", "jeeva@2001");
    }

    @When("user click remember box")
    public void remember() {
        lp.remember();
    }

    @When("user click login button")
    public void loginbutton() {
        lp.loginbutton();
    }

    @Then("the product page is displayed")
    public void next() throws InterruptedException {
    	String actualEmail = lp.actualEmail();
    	String expectedEmail = "jeevamukesh2@gmail.com";
    	Assert.assertEquals(actualEmail, expectedEmail);
    	System.out.println("Login verified successfully.");
        lp.logout();
        dr.quit();
    }
    
    @Then("the error message is displayed")
    public void error() throws InterruptedException {
    	String actualError = lp.actualError();
    	String expectedError ="Login was unsuccessful. Please correct the errors and try again. No customer account found";
    	Assert.assertEquals(actualError, expectedError);
    	System.out.println("Login verified unsuccessfully.");
    	Thread.sleep(2000);
        dr.quit();
    }
    
}